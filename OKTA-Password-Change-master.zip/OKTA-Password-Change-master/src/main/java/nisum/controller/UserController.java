package nisum.controller;

import nisum.model.User;
import nisum.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
public class UserController {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private UserService userService;

    @Autowired
    private User user;

    @GetMapping("/changepassword")
    	public String getPasswordResetForm(@ModelAttribute("user") User user){
        return "reset_password";
    }

    @PostMapping("/changepassword")
    public String updatePassword(@Valid User user, BindingResult result,RedirectAttributes ra) {

        if(result.hasErrors()){
            user.setResponseMessage(result.getAllErrors().get(0).getDefaultMessage());
            return "reset_password";
        }
        	
            user.setUserName(user.getUserName().split("@")[0]);
            userService.connectUser(user);
            user.setUserName("");
            ra.addFlashAttribute("user", user);
            
        return "redirect:changepassword";
    }

    

}