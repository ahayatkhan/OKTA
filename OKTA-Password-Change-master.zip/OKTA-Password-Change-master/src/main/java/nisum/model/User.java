package nisum.model;

import nisum.validation.FieldsValueMatch;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotNull;

@FieldsValueMatch.List({
        @FieldsValueMatch(
                field = "newPass",
                fieldMatch = "confNewPass",
                message = "New passwords don't match!"
        )

})

@Component
public class User {

    @NotNull(message = "User name is compulsory")
    @NotBlank(message = "User name is compulsory")
    private String userName;
    @NotNull(message = "Current Password cannot be null")
    @NotBlank(message = "Current Password cannot be null")
    private String oldPass;
    @NotNull(message = "New Password cannot be null")
    @NotBlank(message = "New Password cannot be null")
    private String newPass;
    @NotNull(message = "New Password confirm field cannot be null")
    @NotBlank(message = "New Password confirm field cannot be null")
    private String confNewPass;
    private String responseMessage;
    private boolean responseError;

    public User() {
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getOldPass() {
        return oldPass;
    }

    public void setOldPass(String oldPass) {
        this.oldPass = oldPass;
    }

    public String getNewPass() {
        return newPass;
    }

    public void setNewPass(String newPass) {
        this.newPass = newPass;
    }

    public String getConfNewPass() {
        return confNewPass;
    }

    public void setConfNewPass(String confNewPass) {
        this.confNewPass = confNewPass;
    }

    public String getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }


    public boolean isResponseError() {
        return responseError;
    }

    public void setResponseError(boolean responseError) {
        this.responseError = responseError;
    }

    public void setResponse(String responseMessage, boolean responseError){
        this.responseMessage = responseMessage;
        this.responseError = responseError;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("User{");
        sb.append("userName='").append(userName).append('\'');
        sb.append(", oldPass='").append(oldPass).append('\'');
        sb.append(", newPass='").append(newPass).append('\'');
        sb.append(", confNewPass='").append(confNewPass).append('\'');
        sb.append(", responseMessage='").append(responseMessage).append('\'');
        sb.append(", isResponseError=").append(responseError);
        sb.append('}');
        return sb.toString();
    }
}
