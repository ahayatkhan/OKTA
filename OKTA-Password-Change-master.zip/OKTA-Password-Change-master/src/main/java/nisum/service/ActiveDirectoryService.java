package nisum.service;

import nisum.model.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import nisum.utility.AESUtility;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.*;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import java.io.UnsupportedEncodingException;
import java.security.Security;
import java.util.Hashtable;

/*
* The utility uses SSL communication with Active Directory to change user password.
* */

@Component
public class ActiveDirectoryService {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Value("${ldaps.url}")
    private String LDAP_URL;

    @Value("${java.keystore.password}")
    private String KEYSTORE_PASSWORD;

    @Value("${java.keystore.path}")
    private String KEYSTORE_PATH;

    @Value("${security.authentication}")
    private String SECURITY_AUTHENTICATION;

    @Value("${security.protocol}")
    private String SECURITY_PROTOCOL;

    @Value("${initial.context.factory}")
    private String INITIAL_CONTEXT_FACTORY;

    @Value("${base.name}")
    private String BASE_NAME;

    private String UTF_CHARSET = "UTF-16LE";

    private LdapContext ctx;

    public ActiveDirectoryService() {
    }

    public void establishContext(User user) throws NamingException, UnsupportedEncodingException {

        Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());

		System.setProperty("javax.net.ssl.trustStore", System.getProperty("java.home").concat(KEYSTORE_PATH));
		LOGGER.debug("Java Keystore path : " + System.getProperty("java.home").concat(KEYSTORE_PATH));
        System.setProperty("javax.net.ssl.trustStorePassword", AESUtility.decrypt(KEYSTORE_PASSWORD));

        Hashtable env = new Hashtable();
        env.put(Context.INITIAL_CONTEXT_FACTORY, INITIAL_CONTEXT_FACTORY);
        env.put(Context.SECURITY_PROTOCOL, SECURITY_PROTOCOL);
        env.put(Context.SECURITY_AUTHENTICATION, SECURITY_AUTHENTICATION);
        env.put(Context.PROVIDER_URL, LDAP_URL);
        env.put(Context.SECURITY_PRINCIPAL, user.getUserName());
        env.put(Context.SECURITY_CREDENTIALS, user.getOldPass());
        ctx = new InitialLdapContext(env, null);
        LOGGER.info("Connection successfully established.");

    }

    public void updatePassword(String username, String newPassword, String oldPassword) throws NamingException, UnsupportedEncodingException {

        String quotedNewPassword = "\"" + newPassword + "\"";
        byte newPwdArray[] = quotedNewPassword.getBytes(UTF_CHARSET);
        String quotedOldPassword = "\"" + oldPassword + "\"";
        byte oldPwdArray[] = quotedOldPassword.getBytes(UTF_CHARSET);

        ModificationItem[] mods = new ModificationItem[2];
        mods[0] = new ModificationItem(DirContext.REMOVE_ATTRIBUTE, new BasicAttribute("unicodePwd", oldPwdArray));
        mods[1] = new ModificationItem(DirContext.ADD_ATTRIBUTE, new BasicAttribute("unicodePwd", newPwdArray));
        ctx.modifyAttributes(getDistinguishedName(username.split("@")[0], ctx), mods);
    }

    private String getDistinguishedName(String username, LdapContext ctx) throws NamingException {

            SearchControls constraints = new SearchControls();
            constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
            String[] attrIDs = {"distinguishedName"};
            constraints.setReturningAttributes(attrIDs);

            NamingEnumeration answer = ctx.search(BASE_NAME, "sAMAccountName=" + username, constraints);
            if (answer.hasMore()) {
                Attributes attrs = ((SearchResult) answer.next()).getAttributes();
                Attribute distinguishedName = attrs.get("distinguishedName");
                LOGGER.debug(distinguishedName.toString());
                return distinguishedName.get(0).toString();
            } else {
                throw new NamingException("Invalid User");
            }
        }

}