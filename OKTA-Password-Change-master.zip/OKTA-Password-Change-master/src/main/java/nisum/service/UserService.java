package nisum.service;


import nisum.model.User;
import nisum.utility.LDAPUtility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.naming.CommunicationException;
import javax.naming.NamingException;
import java.io.UnsupportedEncodingException;

@Service
@PropertySource("classpath:messages.properties")
public class UserService {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private ActiveDirectoryService adServ;
    
    @Autowired
    private Environment env;

    public UserService() {
    }

    public void connectUser(User user){

        try {
            if (isUserAuthenticated(user)) {
                LOGGER.info("Going to change password for user " + user.getUserName());
                adServ.updatePassword(user.getUserName(), user.getNewPass(), user.getOldPass());
                LOGGER.info("Password successfully changed for user " + user.getUserName());
                user.setResponse(env.getProperty("ldap.info.pass"), false);
            }
        }catch (CommunicationException ce){
            String msg = env.getProperty("ldap.error.general");
            LOGGER.error(msg,ce);
            user.setResponse(msg, true);
        }catch (NamingException ne){
            String errorMessage = getTranslatedMessage(ne.getMessage());
            LOGGER.error(errorMessage,ne);
            user.setResponse(errorMessage, true);
        } catch (Exception e){
            String msg = env.getProperty("ldap.error.general");
            LOGGER.error(msg,e);
            user.setResponse(msg, true);
        }
    }

    private Boolean isUserAuthenticated(User user) throws NamingException, UnsupportedEncodingException {
        LOGGER.info("Going to establish ldap connection for user " + user.getUserName());
        adServ.establishContext(user);
        LOGGER.info("User " + user.getUserName() + " authenticated.");
    return true;
    }

    public String getTranslatedMessage(String exceptionMessage){

        int errorCode = LDAPUtility.parseMessageForParentErrorCodes(exceptionMessage);
        String errorMessage = "";
         switch (errorCode) {
             case 49:
                 String subErrorCode = LDAPUtility.parseMessageForSubErrorCodes(exceptionMessage);
                 errorMessage = this.getErrorMessage(errorCode, subErrorCode);
                 break;
             default :
            	 errorMessage = this.getErrorMessage(errorCode, null);
            	 errorMessage = StringUtils.isEmpty(errorMessage) ? env.getProperty("ldap.error.general") : errorMessage;
         }

         return errorMessage;
     }
    
    private String getErrorMessage(int errorCode, String subErrorCode){
    	
    	String key = "ldap.error."+errorCode;
    	if(!StringUtils.isEmpty(subErrorCode)) {
    		key = (key+"."+subErrorCode);
    	}
    	return env.getProperty(key);
    }
}
