package nisum.utility;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LDAPUtility {
	
	
	public static int parseMessageForParentErrorCodes(String exceptionMessage) {
	
		String regex = "error code [0-9][0-9]";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(exceptionMessage);

        int errorCode=0;
        if(matcher.find()) {
            errorCode = Integer.valueOf(matcher.group(0).substring(11,13));
        }

        return errorCode;
	}

	public static String parseMessageForSubErrorCodes(String exceptionMessage) {
		
		String subCodeRegex = "data [0-9][0-9]?[a-z]|data [0-9][0-9]?[0-9]";
        Pattern subErrorCodePattern = Pattern.compile(subCodeRegex);
        Matcher subErrorCodeMatcher = subErrorCodePattern.matcher(exceptionMessage);

        String subErrorCode="";
        if(subErrorCodeMatcher.find()){
            subErrorCode = subErrorCodeMatcher.group(0).substring(5,8);
        }
        return subErrorCode;
	}

}
